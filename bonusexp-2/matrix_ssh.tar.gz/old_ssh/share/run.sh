#!/bin/sh
sshd;
sleep 365d;
